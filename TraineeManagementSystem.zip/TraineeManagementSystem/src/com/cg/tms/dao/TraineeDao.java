package com.cg.tms.dao;

import java.util.List;


import com.cg.tms.entities.Trainee;

public interface TraineeDao {

	public void insert(Trainee t);
    public void delete(Integer id);
    public List<Trainee> retrieveAllTrainees();
    public Trainee retrieveTrainee(Integer id);
    public void modify(Trainee t);
}

