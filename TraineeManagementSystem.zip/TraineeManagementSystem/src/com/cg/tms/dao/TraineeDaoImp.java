package com.cg.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;




import com.cg.tms.entities.Trainee;


@Repository
public class TraineeDaoImp implements TraineeDao{

	@PersistenceContext
	private EntityManager em;
	@Override
	public void insert(Trainee t) {
		// TODO Auto-generated method stub
		em.persist(t);
		
	}
	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		Trainee t=em.find(Trainee.class,id);
		em.remove(t);
	}
	@Override
	public List<Trainee> retrieveAllTrainees() {
		// TODO Auto-generated method stub
		String jpql="select t FROM Trainee t ";
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
		return query.getResultList();
	}
	@Override
	public Trainee retrieveTrainee(Integer id) {
		// TODO Auto-generated method stub
		Trainee t=em.find(Trainee.class,id);
		return t;
	}
	@Override
	public void modify(Trainee t) {
		// TODO Auto-generated method stub
		
		em.merge(t);
		
	}

}
