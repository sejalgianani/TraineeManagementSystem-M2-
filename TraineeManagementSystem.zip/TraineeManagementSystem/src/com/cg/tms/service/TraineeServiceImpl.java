package com.cg.tms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dao.TraineeDao;
import com.cg.tms.entities.Trainee;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	TraineeDao tdao;
	
	@Override
	public void insert(Trainee t) {
		// TODO Auto-generated method stub
		tdao.insert(t);
	}

	@Override
	public void delete(Integer id) {
		// TODO Auto-generated method stub
		tdao.delete(id);
	}

	@Override
	public List<Trainee> retrieveAllTrainees() {
		// TODO Auto-generated method stub
		return tdao.retrieveAllTrainees();
	}

	@Override
	public Trainee retrieveTrainee(Integer id) {
		// TODO Auto-generated method stub
		return tdao.retrieveTrainee(id);
	}

	@Override
	public void modify( Trainee t) {
		// TODO Auto-generated method stub
		 tdao.modify(t);
	}

}
