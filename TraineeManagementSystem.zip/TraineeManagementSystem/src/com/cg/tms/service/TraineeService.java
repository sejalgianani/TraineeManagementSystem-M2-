package com.cg.tms.service;

import java.util.List;






import com.cg.tms.entities.Trainee;

public interface TraineeService {

	public void insert(Trainee t);
	public void delete(Integer id);	
	List<Trainee> retrieveAllTrainees();
	public Trainee retrieveTrainee(Integer id);
	public void modify(Trainee t);
	
}
