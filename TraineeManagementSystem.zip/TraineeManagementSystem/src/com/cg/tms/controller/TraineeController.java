package com.cg.tms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.tms.entities.Trainee;
import com.cg.tms.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService tser;
	
	@RequestMapping("start")
	public String showHome(Model model)
	{
	
		return "Login";
	}
	
	@RequestMapping("Validate")
	public String validation(@RequestParam("username")String username,@RequestParam("password")String pwd,Model model)
	{
	
		if(username.equals("capgemini") && pwd.equals("corp123"))
		{	
		return "menu";
		}
		else
		{
			return "Login";
			
		}
		
	}
		@RequestMapping("insert")
		
		public String insertTrainee(Model model)
		{
		Trainee t=new Trainee();
		model.addAttribute("t",t);
		return "insertdetails";
		
		
	}
		
		@RequestMapping("check")
		public String checking( @Valid @ModelAttribute("t")Trainee t, BindingResult res, Model model)
		{
			if(res.hasErrors())
			{
				model.addAttribute("t",t);
				return "insertdetails";
			}
			else
			{
				tser.insert(t);
				model.addAttribute("t",t);
				return "success";
			}
			
		
		}
		
		@RequestMapping("retrieveall")
		public String retrieveAllTrainees(Model model)
		{
			List<Trainee> tlist=tser.retrieveAllTrainees();
			model.addAttribute("tlist",tlist);
			return "retrieveall";
		}
		
		@RequestMapping("delete.obj")
		public String deleteTrainee(Model model)
		{
			Trainee t=new Trainee();
			model.addAttribute("t",t);
			return "delete";
		}
		
		
		@RequestMapping("deletetrainee")
		public String deleting(@RequestParam("id")Integer id, Model model)
		{	
				tser.delete(id);;
				model.addAttribute("id",id);
				return "success";
		}
		
		@RequestMapping("retrieve")
		public String retrieve(Model model)
		{
			Trainee t=new Trainee();
			model.addAttribute("t",t);
			return "retrieve";
		}
		
		@RequestMapping("displaytrainee")
		public String displaytrainee(@RequestParam("id")Integer id, Model model)
		{
			
			model.addAttribute("id",id);
			Trainee tt=tser.retrieveTrainee(id);
			model.addAttribute("tt",tt);
			return "displaytrainee";
		}
		
		@RequestMapping("modify")
		public String modify(Model model)
		{
			
			return "modify";
		}
		
		@RequestMapping("modifying")
		public String modifying(@RequestParam("id")Integer id,Model model)
		{
			Trainee t=new Trainee();
			t.setTraineeId(id);
			model.addAttribute("t",t);
			return "modifying";
		}
		
		
		
		@RequestMapping("updated")
		public String modifying(@Valid@ModelAttribute("t")Trainee t,BindingResult res, Model model)
		{
				
			if(res.hasErrors())
			{
				model.addAttribute("t",t);
				return "modifying";
			}
			else
			{
				tser.modify(t);
				model.addAttribute("t",t);
				return "success";
			}
			
		}
		
		
		
		}
		

